//Procurar um pokemon por nome
import { pokemons } from "./data.js"; //ao importar tem que ser o mesmo nome do export, por isso estava dando erro , o nome era !=

const nameToSearch = "pikachu";

//foi filtrado para que fosse encontrado de acordo com o nome desejado, se usar o metodo filter tbm da certo
//procurando o pokemon
const serchForPokemon = pokemons.find(
  (pokemon) => pokemon.name === nameToSearch
);

console.log("--------------------NAME-------------------");
console.log(serchForPokemon);

const sameType = "electric";

const typeOfPokemons = pokemons.filter((pokemonType) =>
  pokemonType.type.includes(sameType)
);
console.log("--------------------TYPE-------------------");
console.log(typeOfPokemons);

const changeTypes = {
  grass: "grama",
  poison: "venenoso", //toxico
  fire: "Fogo",
  flying: "Voador",
  water: "Água",
  bug: "Inseto",
  normal: "Normal",
  electric: "Elétrico",
  ground: "Terra",
  fairy: "Fada",
  fighting: "Lutador",
  psychic: "Psíquico",
  rock: "Pedra",
  steel: "aço",
  ice: "Gelo",
  ghost: "Fantasma",
};

//o forEach é util para poder executar alguma coisa de cada elemento de um array, por isso usei ele par trocar os tipos e o .map usa par
//auterar os nomes

pokemons.forEach((pokemonChange) => {
  pokemonChange.type = pokemonChange.type.map(
    (translation) => changeTypes[translation]
  );
});

console.log("--------------------CHANGE-------------------");
console.log(pokemons);
