const lib = require("../libAtv");

describe("doubleANumber", () => {
  it("Should return a number multiplied", () => {
    //---> testes q dao CERTO:

    const result = lib.doubleANumber(2);
    expect(result).toBe(4);

    const result1 = lib.doubleANumber(-255);
    expect(result1).toBe(-510);

    //---> testes q dao ERRO:
  });

  it("Should return wrong test", () => {
    const result = lib.doubleANumber(-255);
    expect(result).toBe(510); //faltou o sinal

    const result1 = lib.doubleANumber(-25);
    expect(result1).toBe(50);
  });
});

describe("createFullName", () => {
  it("Should return the concatenation of the two names", () => {
    //---> testes q dao CERTO:

    const result = lib.createFullName("Juliana", "Sartori"); //padrao recebido
    expect(result).toBe("Juliana Sartori"); //aq eh o padrao esperado

    //---> testes q dao ERRADO:
  });

  it("Should return wrong test", () => {
    const result = lib.createFullName("Juliana", "Sartori"); //padrao recebido
    expect(result).toBe("Juliana Silva");
    expect(result).toBe("Julia Sartori");
  });
});

describe("calculateTheLenghtOfAString2", () => {
  it("Should return a length of a string", () => {
    //---> testes q dao CERTO:

    const result = lib.calculateTheLenghtOfAString2("Tamanho");
    expect(result).toEqual(7);
    const result1 = lib.calculateTheLenghtOfAString2(" ");
    expect(result1).toBe(1);

    //---> testes q dao ERRADO:
  });

  it("Should return wrong test", () => {
    const result = lib.calculateTheLenghtOfAString2("Tamanho");
    expect(result).toEqual(10);
    const result1 = lib.calculateTheLenghtOfAString2("");
    expect(result1).toEqual(1);
  });
});

describe("numbersArrayIntoString", () => {
  it("Should return 1 point every three strings place", () => {
    //---> testes q dao CERTO:
    const result = lib.numbersArrayIntoString([1, 2, 3, 4, 5, 6, 7, 8]);
    expect(result).toBe("123.456.78");
    const result1 = lib.numbersArrayIntoString([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
    expect(result1).toBe("123.456.789.10");
  });

  //---> testes q dao ERRADO:
  it("Should return wrong test", () => {
    const result = lib.numbersArrayIntoString([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
    expect(result).toBe("123.456.789"); //aq falta o .10
    //const result = lib.numbersArrayIntoString([1, 2, 3, 4, 5, 6, 7, 8, 9]);
    expect(result).toBe("1234.56.789"); //ponto em lugar errado
  });
});

describe("addNewLanguage", () => {
  // //---> testes q dao CERTO:

  it("Should return a array with old and new languages", () => {
    const result = lib.addNewLanguage(lib.programming, "Swift");
    // expect(result).toMatchObject({
    //   languages: ["JavaScript", "Python", "Ruby", "Swift"],
    //   isChallenging: true,
    //   isRewarding: true,
    //   difficulty: 8,
    //   jokes:
    //     "http://stackoverflow.com/questions/234075/what-is-your-best-programmer-joke",
    // });
    expect(result).toMatchObject(lib.programming);
  });

  it("should return an object with language array bigger than it was before", () => {
    const initialLength = lib.programming.languages.length;
    const result = lib.addNewLanguage(lib.programming, "Swift");
    expect(result.languages.length).toBeGreaterThan(initialLength);
  });

  //---> testes q dao ERRADO:
  //passou no tste porem nao foi add a linguagem, logo esta errada
  it("should return an object with language array bigger than it was before", () => {
    const initialLength = lib.programming.languages.length;
    const result = lib.addNewLanguage(lib.programming);
    expect(result.languages.length).toBeGreaterThan(initialLength);
  });
  it("should return an object with language array bigger than it was before", () => {
    const initialLength = lib.programming.languages.length;
    const result = lib.addNewLanguage(lib.programming);
    expect(result.languages.length).toBeGreaterThan(initialLength, null);
  });
});

describe("votersResult", () => {
  it("Should a return is a object", () => {
    const result = lib.votersResult(lib.voters);
    expect(typeof result).toBe("object");
  });

  it("Should a return is the number of voters", () => {
    const result = lib.votersResult(lib.voters);
    expect(result).toMatchObject({
      numYoungVotes: 1,
      numYoungPeople: 4,
      numMidVotesPeople: 3,
      numMidsPeople: 4,
      numOldVotesPeople: 3,
      numOldsPeople: 4,
    });
  });
});
