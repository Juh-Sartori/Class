import { pokemons } from "./data.js";

const nameToSearch = "pikachu";

const serchForPokemon = pokemons.find(
  (pokemon) => pokemon.name === nameToSearch
);

const sameType = "electric";

const typeOfPokemons = pokemons.filter((pokemonType) =>
  pokemonType.type.includes(sameType)
);

const changeTypes = {
  grass: "grama",
  poison: "venenoso",
  flying: "Voador",
  water: "Água",
  bug: "Inseto",
  normal: "Normal",
  electric: "Elétrico",
  ground: "Terra",
  fairy: "Fada",
  fighting: "Lutador",
  psychic: "Psíquico",
  rock: "Pedra",
  steel: "aço",
  ice: "Gelo",
  ghost: "Fantasma",
};

pokemons.forEach((pokemonChange) => {
  pokemonChange.type = pokemonChange.type.map(
    (translation) => changeTypes[translation]
  );
});
